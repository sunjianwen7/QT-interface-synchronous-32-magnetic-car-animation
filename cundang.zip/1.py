import socket


class Led_Client():
    def __init__(self):
        host = "127.0.0.1"
        port = 1236
        self.__socket_= socket.socket()
        self.__socket_.connect((host, port))
        while 1:
            input("gogogo")
Led_Client()